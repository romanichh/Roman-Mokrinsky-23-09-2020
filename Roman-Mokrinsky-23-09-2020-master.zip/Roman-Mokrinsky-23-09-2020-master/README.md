# Roman-Mokrinsky-23-09-2020
test project

Checking of footer services:
1. Whatsapp service on the left side of page
2. Social Media Bar icon on footer
3. Facebook service icon on footer
4. WhatsApp service icon on footer
5. LinkedIn service icon on footer

Checking of footer elements:
1. Checking that manager contact ss presented on footer
2. Cheking of scroll button functionality.

Checking of messaging services:
1. Checking message sending from footer
2. Checking contact message sending
3. Checking message sending from PopUp

Checking that especial client is presented in slide

Open site test
